<!DOCTYPE html>

<html>

<head>
    <title>Katarina bresaola</title>

<style>
		
		body
		{
			font-size: 13px;
		}
	
		::-webkit-scrollbar {
    width: 0em;
    height: 2em
}

	</style>
</head>

<body>


    <table>
        <tr>
            <td colspan="3" align="center">
                <iframe width="700" frameborder="0" height="410" src="product/23.jpg" name="largimg"></iframe>
            </td>
        </tr>
        <tr>
            <td colspan="3">
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</td>
        </tr>
      
    </table>



</body>
