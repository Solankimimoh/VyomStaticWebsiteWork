<!DOCTYPE html>

<html>

<head>
	<title>Katarina bresaola</title>

	<style>
		body {
			font-size: 13px;
		}
		
		::-webkit-scrollbar {
			width: 0em;
			height: 2em
		}

	</style>

</head>

<body>

	<table width="100%">
		<tr>
			<td colspan="2" align="center">
				<iframe width="510" frameborder="0" height="690" src="product/21.jpg" name="largimg"></iframe>
			</td>
		</tr>
		<tr>
			<td width="40%" valign="top">
				Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.

			</td>
			<td width="60%">
				<table align="right" cellspacing="9">

					<tr>
						<td>
							<a href="product/21.jpg" target="largimg"><img src="product/21.jpg" width="100" height="100" /> </a>
						</td>
						<td>
							<a href="product/22.jpg" target="largimg"><img src="product/22.jpg" width="100" height="100" /> </a>
						</td>

					</tr>

				</table>

			</td>
		</tr>
	</table>

</body>
