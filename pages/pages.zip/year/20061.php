<!DOCTYPE html>

<html>

<head>
	<title>2006 Project</title>

	<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">

	<style>
		body,
		html {
			font-size: 13px;
			font-family: 'Lato', sans-serif;
			margin: 0;
			overflow-y: auto;
			height: 100%;
		}
		
		 ::-webkit-scrollbar {
			width: .3em;
			height: .3em
		}
		
		 ::-webkit-scrollbar-thumb {
			background: #dcdcdc
		}
		
		 ::-webkit-scrollbar-track {
			background: #dcdcdc
		}
		
		.space1 {
			margin-bottom: 30px;
		}

	</style>



</head>

<body>

	<table width="100%" height="100%">
		<tr>
			<td colspan="2" align="center" height="100%">

				<img style="height: 99vh;" class="space1" id="largeImage" src="product/year/2006/1.png" />



			</td>
		</tr>
		<tr>
			<td colspan="2" width="40%" valign="top" style="line-height: 1.6;">
				<p style="margin-left:20px;margin-top:0;margin-bottom:0;">‘untitled’ <br/> plater with steel armature <br/> 9’ x 4’ x 5’ <br/> 2006
				</p>
			</td>

		</tr>
	</table>




</body>
